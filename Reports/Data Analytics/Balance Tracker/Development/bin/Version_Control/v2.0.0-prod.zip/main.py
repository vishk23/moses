"""
Balance Tracker - revised
Developed by CD
[v2.0.0-prod]
"""
from pathlib import Path

import pandas as pd # type: ignore

import src.balance_tracker_pipeline_v2
import src.cdutils.database.sliding_window
import src.excel_output
import src.monthly_delta
from src._version import __version__

def main():
    # Fetch Data from COCC
    data_prior, data_current = src.cdutils.database.sliding_window.fetch_data()

    _, data_prior_summary = src.balance_tracker_pipeline_v2.main_pipeline_bt(data_prior)
    _, data_current_summary = src.balance_tracker_pipeline_v2.main_pipeline_bt(data_current)

    # OUTPUT_PATH = Path('./output/data_prior_summary.xlsx')
    # data_prior_summary.to_excel(OUTPUT_PATH, engine='openpyxl', index=False)

    # OUTPUT_PATH = Path('./output/data_current_summary.xlsx')
    # data_current_summary.to_excel(OUTPUT_PATH, engine='openpyxl', index=False)

    monthly_delta = src.monthly_delta.creating_monthly_delta(data_prior_summary, data_current_summary)

    TEMPLATE_PATH = Path('./output/Portfolio_Balance_Tracker_2025YTD.xlsx')
    OUTPUT_PATH = Path('./output/Portfolio_Balance_Tracker_2025YTD.xlsx')
    # OUTPUT_PATH = Path('./output/Portfolio_Balance_Tracker_2025YTD_test.xlsx')

    src.excel_output.update_excel_template(TEMPLATE_PATH, monthly_delta, OUTPUT_PATH)   

if __name__ == '__main__':
    print(f"Starting {__version__}")
    main()
    print("Complete!")

