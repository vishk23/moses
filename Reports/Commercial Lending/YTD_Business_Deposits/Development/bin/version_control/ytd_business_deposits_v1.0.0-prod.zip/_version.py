# YTD Deposit Report (monthly)
__version__ = "v1.0.0-prod"