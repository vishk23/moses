# Alerts
__version__ = "v2.1.8-prod"