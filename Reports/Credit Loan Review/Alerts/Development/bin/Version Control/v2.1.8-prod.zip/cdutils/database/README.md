Database Connection
===

- This module allows for simple connection the COCC Databases
    - engine 1: R1625
    - engine 2: 1625dm

The interactive is helpful if you need to query something live, while the paths are slightly different to function as a module for the database_connect.py