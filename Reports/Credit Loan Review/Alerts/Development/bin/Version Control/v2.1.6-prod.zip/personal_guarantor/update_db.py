import sqlite3
import pandas as pd
from typing import List, Tuple


# Define database and CSV file paths
CSV_FILE = r"Z:\Chad Projects\Alerts\Production\assets\xactus\pfs_permission.csv"
DB_FILE = r"Z:\Chad Projects\Alerts\Production\assets\xactus\personal_guarantor.db"
TABLE_NAME = r""